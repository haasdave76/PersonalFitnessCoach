# Personal Fitness Coach — AI text & microphone v0.3

This is a drop-in replacement for the existing GitHub Pages `index.html`, plus one server-side Supabase Edge Function. **Do not publish any OpenAI secret in GitHub.**

## Deploy the server function first

1. In the Supabase dashboard for `PersonalFitnessCoach`, go to **Edge Functions → Deploy a new function → Via Editor** (the naming may differ). Name it **`fitness-coach`**. Paste the content of `supabase/functions/fitness-coach/index.ts` and deploy.
2. Find **Edge Function Secrets**. Create a secret named exactly `OPENAI_API_KEY` containing your OpenAI secret API key. Keep it only in Supabase. You do not need to send the key to ChatGPT.
3. Leave **Verify JWT** enabled (the function also verifies the logged-in user with Supabase Auth). The deployed endpoint will be `https://soerkequbxfgeldzexpy.supabase.co/functions/v1/fitness-coach`.
4. Replace the root `index.html` in your public GitHub repository `haasdave76/PersonalFitnessCoach` with this new file. Commit and wait for GitHub Pages to deploy.
5. Open `https://haasdave76.github.io/PersonalFitnessCoach/`, sign in, choose **Workout**, start a workout and type: **“I did 10 reps at 115 pounds and it felt easy. What should I do next? Is 115 plates-only or total?”**
6. Try the microphone button. Some browsers do not support `SpeechRecognition` (especially iPhone Home Screen web apps). In that case, use iOS keyboard dictation or type. Speech is **tap to dictate then Send**, not a streaming voice conversation.

## Status and limitations

- The app sends current workout details and the latest 40 **completed, synced** sets to the secure function for advice. Unfinished sets are included as current-workout context but aren't uploaded to cloud history until completion.
- AI responses **suggest** changes, but do not automatically swap an exercise or modify recorded weights. Manually log and confirm any changes.
- The mic depends on browser support and permission. The text coach can work without voice.
- No new database tables needed; it uses your existing three tables and existing account policies.
- Project browser storage is not yet isolated between different logins on one device. Use only your own account until this is fixed.
- Syntax checked; **live OpenAI API and Supabase deployment cannot be tested without your account access**.
- OpenAI API usage is separately billed. Monitor spending in the OpenAI Platform dashboard.
